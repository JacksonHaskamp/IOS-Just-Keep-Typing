//
//  Just_Keep_TypingApp.swift
//  Just-Keep-Typing
//
//  Created by Jackson on 5/1/22.
//

import SwiftUI

@main
struct Just_Keep_TypingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
